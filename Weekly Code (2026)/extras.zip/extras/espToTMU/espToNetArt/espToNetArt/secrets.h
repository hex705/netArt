// log on info -- keep private

//   ***********************
//   do NOT share to github
//   ***********************


// ************** wifi login info ****************************

// at your home you can put your:
 //const char ssid[] = "YOUR_WIFI_NAME"; // wifi name
 //const char password[] = "YOUR_WIFI_PASSWORD"; // wifi password

// in rcc357 - during class
 const char ssid[] = "NETART2";    // wifi name -- OR --  NETART2
 const char password[] = "rapiddiamond499";  // wifi password

// in the makerspace
 //const char ssid[] = "makerSpace-netArt";    // wifi name - check 
 //const char password[] = "rapi******d4*9";  // wifi password

// at steve's hoouse you can put his credentials:
 //const char ssid[] = "someFruit"; // wifi name
 //const char password[] = "**********!"; // wifi password

