// TMU wifi credentials 

const char ssid[] = "TMU";    // wifi name 

#define EAP_IDENTITY "yourEmail@torontomu.ca"  // enter full torontomu email address
#define EAP_PASSWORD "*********************"   // your torontomu password