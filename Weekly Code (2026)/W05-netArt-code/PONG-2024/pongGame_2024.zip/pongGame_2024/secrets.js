// https://www.youtube.com/watch?v=Yk18ZKvXBj4
// note order in html matters -- load secrets before

// trying to keep these details off of github



/*

ONLY ONE OF THE CODE BLOCKS below AN BE ACTIVE!!!!!!!  Comment out the other. 

*/

// // **************  for testing on day of ... this is the CLASS instance *************

/* TOKEN : mqtt://netart-2024:VhVC++++++W7JPa8@netart-2024.cloud.shiftr.io */


// let URL_FROM_INSTANCE = 'netart-2024.cloud.shiftr.io'; // "your-URL-from-token"

// let DEVICE_NAME_IN_QUOTES    = 'YOUR_NAME_TESTING_pong2024'; // change this name while you test
// let INSTANCE_OR_USER_NAME    = 'netart-2024'; //'INSTANCE-NAME-HERE'
// let CHECK_DtwoL_FOR_MQTT_KEY = 'VhVC++++++W7JPa8';  // 'REPLACE-WITH-KEY-from-token'

// // *********************   end testing instance *************************************


// REMEMBER ONLY ONE OF THESE CAN BE ACTIVE 


// **************  for PLAYING PONG on day of ... this is the PONG instance *************

/* TOKEN : mqtt://netart-pong-2024:nwQ++++++++5HCps@netart-pong-2024.cloud.shiftr.io  */

let URL_FROM_INSTANCE = 'netart-pong-2024.cloud.shiftr.io'; // "your-URL-from-token"

let DEVICE_NAME_IN_QUOTES    = 'steve-PONG-2024_rcc357';
let INSTANCE_OR_USER_NAME    = 'netart-pong-2024'; //'INSTANCE-NAME-HERE'
let CHECK_DtwoL_FOR_MQTT_KEY = 'nwQ++++++++5HCps';  // 'REPLACE-WITH-KEY-from-token'


// *********************   end PLAYING PONG  instance *************************************
