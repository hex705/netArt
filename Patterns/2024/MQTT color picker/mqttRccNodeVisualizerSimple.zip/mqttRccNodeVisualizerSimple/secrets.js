// https://www.youtube.com/watch?v=Yk18ZKvXBj4
// note order in html matters -- load secrets before

// trying to keep these details off of github


// let URL_FROM_INSTANCE = 'public.cloud.shiftr.io'; // "your-URL-from-token"

// let DEVICE_NAME_IN_QUOTES    = 'an_mqttTemplateTest';
// let INSTANCE_OR_USER_NAME    = 'public'; //'INSTANCE-NAME-HERE'
// let CHECK_DtwoL_FOR_MQTT_KEY = 'public';  // 'REPLACE-WITH-KEY-from-token'





// *********  class shiftr instance ***********

// check D2L for class info if required
// mqtt://netart-2024:VhVC++++++W7JPa8@netart-2024.cloud.shiftr.io

let URL_FROM_INSTANCE = 'netart-2024.cloud.shiftr.io'; // "your-URL-from-token"

let DEVICE_NAME_IN_QUOTES    = 'mqttDebug-errors';
let INSTANCE_OR_USER_NAME    = 'netart-2024'; //'INSTANCE-NAME-HERE'
let CHECK_DtwoL_FOR_MQTT_KEY = 'VhVCF97cSuW7JPa8';  // 'REPLACE-WITH-KEY-from-token'
